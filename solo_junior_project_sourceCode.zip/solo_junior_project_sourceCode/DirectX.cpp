#include"DirectX.h"

JMDirectXFrame::JMDirectXFrame()
{
	vSync			= false;
	DirectObject	= 0;
	DirectDevice	= 0;
	GameFont		= 0;
	currTime		= 0;
	prevTime		= 0;
	FPS				= 0;
	DIObject		= 0;
	DIKeyboard		= 0;
	DIMouse			= 0;
	videoPlay		= true;
}

JMDirectXFrame::~JMDirectXFrame()
{
	Shutdown();
}

void JMDirectXFrame::Init(HWND &hWnd, HINSTANCE &hInstance, bool windowed)
{
	hand2Wnd = hWnd;

	DirectObject = Direct3DCreate9(D3D_SDK_VERSION);

	//ScreenMode
	for(int i = 0; i < DirectObject->GetAdapterCount(); i++)
	{
		UINT modeCnt = DirectObject->GetAdapterModeCount(i, D3DFMT_X8R8G8B8);
		for(int j = 0; j < modeCnt; j++)
		{
			DirectObject->EnumAdapterModes(i, D3DFMT_X8R8G8B8, j, &mode);
		}
	}

	D3DPRESENT_PARAMETERS D3Dpp;
	ZeroMemory(&D3Dpp, sizeof(D3Dpp));												// NULL the structure's memory

	D3Dpp.hDeviceWindow					= hWnd;										// Handle to the focus window
	D3Dpp.Windowed						= windowed;									// Windowed or Full-screen boolean
	D3Dpp.AutoDepthStencilFormat		= D3DFMT_D24S8;								// Format of depth/stencil buffer, 24 bit depth, 8 bit stencil
	D3Dpp.EnableAutoDepthStencil		= TRUE;										// Enables Z-Buffer (Depth Buffer)
	D3Dpp.BackBufferCount				= 1;										// Change if need of > 1 is required at a later date
	D3Dpp.BackBufferFormat				= D3DFMT_X8R8G8B8;							// Back-buffer format, 8 bits for each pixel
	D3Dpp.BackBufferHeight				= mode.Height;
	D3Dpp.BackBufferWidth				= mode.Width;
	D3Dpp.SwapEffect					= D3DSWAPEFFECT_DISCARD;					// Discard back-buffer, must stay discard to support multi-sample
	D3Dpp.PresentationInterval			= vSync ? D3DPRESENT_INTERVAL_DEFAULT : D3DPRESENT_INTERVAL_IMMEDIATE; // Present back-buffer immediately, unless V-Sync is on								
	D3Dpp.Flags							= D3DPRESENTFLAG_DISCARD_DEPTHSTENCIL;		// This flag should improve performance, if not set to NULL.
	D3Dpp.FullScreen_RefreshRateInHz	= mode.RefreshRate;
	

	D3Dpp.MultiSampleQuality			= 0;										// MSAA currently off, check documentation for support.
	D3Dpp.MultiSampleType				= D3DMULTISAMPLE_NONE;						// MSAA currently off, check documentation for support.

	//DeviceCap
	DWORD deviceBehaviorFlags = 0;
	DirectObject->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &DeviceCap);

	if(DeviceCap.DevCaps & D3DCREATE_HARDWARE_VERTEXPROCESSING)
	{
		deviceBehaviorFlags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;	
	}
	else
	{
		deviceBehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING; 
	}
	
	if(DeviceCap.DevCaps & D3DDEVCAPS_PUREDEVICE && deviceBehaviorFlags & D3DCREATE_HARDWARE_VERTEXPROCESSING)
	{
		deviceBehaviorFlags |= D3DCREATE_PUREDEVICE;	
	}
	
	DirectObject->CreateDevice(
		D3DADAPTER_DEFAULT,		// which adapter to use, set to primary
		D3DDEVTYPE_HAL,			// device type to use, set to hardware rasterization
		hWnd,					// handle to the focus window
		deviceBehaviorFlags,	// behavior flags
		&D3Dpp,					// presentation parameters
		&DirectDevice);			// returned device pointer
	
	//Font
	AddFontResourceExA("meyiro_font.otf", 0, 0);
	D3DXCreateFontA(DirectDevice, 36, 15, 0, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "meyiro_font.otf", &GameFont);
	D3DXCreateFontA(DirectDevice, 72, 30, 0, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "meyiro_font.otf", &TitleFont);

	//Input
	DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&DIObject, NULL);
	DIObject->CreateDevice(GUID_SysKeyboard, &DIKeyboard, NULL);
	DIObject->CreateDevice(GUID_SysMouse, &DIMouse, NULL);
	DIKeyboard->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE);
	DIKeyboard->SetDataFormat(&c_dfDIKeyboard);
	DIMouse->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE);
	DIMouse->SetDataFormat(&c_dfDIMouse2);

	//FMOD
	AudResult = FMOD::System_Create(&AudSystem);
	ERRCHECK(AudResult);

	AudResult = AudSystem->getVersion(&version);
	ERRCHECK(AudResult);

	if(version < FMOD_VERSION)
	{
		printf("Error!  You are using an old version of FMOD %08x.  This program requires %08x\n", version, FMOD_VERSION);
		//return 0;
	}

	AudResult = AudSystem->getNumDrivers(&numDrivers);
	ERRCHECK(AudResult);

	if(numDrivers == 0)
	{
		AudResult = AudSystem->setOutput(FMOD_OUTPUTTYPE_NOSOUND);
		ERRCHECK(AudResult);
	}
	else
	{
		AudResult = AudSystem->getDriverCaps(0, &AudCap, 0, &SpeakerMode);
		ERRCHECK(AudResult);

		AudResult = AudSystem->setSpeakerMode(SpeakerMode);
		ERRCHECK(AudResult);

		if (AudCap & FMOD_CAPS_HARDWARE_EMULATED)             /* The user has the 'Acceleration' slider set to off!  This is really bad for latency!. */
		{                                                   /* You might want to warn the user about this. */
			AudResult = AudSystem->setDSPBufferSize(1024, 10);
			ERRCHECK(AudResult);
		}

		AudResult = AudSystem->getDriverInfo(0, name, 256, 0);
		ERRCHECK(AudResult);

		if (strstr(name, "SigmaTel"))   /* Sigmatel sound devices crackle for some reason if the format is PCM 16bit.  PCM floating point output seems to solve it. */
		{
			AudResult = AudSystem->setSoftwareFormat(48000, FMOD_SOUND_FORMAT_PCMFLOAT, 0, FMOD_DSP_RESAMPLER_LINEAR);
			ERRCHECK(AudResult);
		}
	}

	//uses 100 virtual voices for initialization
	AudResult = AudSystem->init(100, FMOD_INIT_NORMAL, 0);
	if (AudResult == FMOD_ERR_OUTPUT_CREATEBUFFER)
	{
		AudResult = AudSystem->setSpeakerMode(FMOD_SPEAKERMODE_STEREO);
		ERRCHECK(AudResult);

		AudResult = AudSystem->init(100, FMOD_INIT_NORMAL, 0);
		ERRCHECK(AudResult);
	}
	
	CoInitialize(NULL);
	CoCreateInstance( CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void**)&GraphBuilder);
	GraphBuilder->QueryInterface( 	IID_IMediaControl, 	(void**)&Control);
	GraphBuilder->QueryInterface( 	IID_IMediaEvent, (void**)&Media);
	GraphBuilder->RenderFile(L"introHD.avi", NULL);
	Control->QueryInterface( IID_IVideoWindow, (void**)&VideoWindow);
	VideoWindow->put_Owner((OAHWND)hand2Wnd);
	VideoWindow->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE);

	RECT WinRect;
	GetClientRect(hand2Wnd, &WinRect);

	VideoWindow->SetWindowPosition(WinRect.left, WinRect.top, WinRect.right, WinRect.bottom);
	Control->Run();

	//Sprites
	D3DXCreateSprite(DirectDevice, &Sprite);
	
	scalMul = (mode.Height/480);

	for(int i = 0; i < 5; i++)
	{
		spriteInfo[i] = new SpriteInfo;
		D3DXMatrixIdentity(&spriteInfo[i]->worldMat);
		D3DXMatrixIdentity(&spriteInfo[i]->scalMat);
		D3DXMatrixIdentity(&spriteInfo[i]->rotMat);
		D3DXMatrixIdentity(&spriteInfo[i]->tranMat);
		spriteInfo[i]->spriteCenter = D3DXVECTOR3(10.0f, -10.0f, 0.0f);

		D3DXMatrixScaling(&spriteInfo[i]->scalMat, scalMul, scalMul, 0.0);
		D3DXMatrixRotationZ(&spriteInfo[i]->rotMat, D3DXToRadian(0));
		D3DXMatrixTranslation(&spriteInfo[i]->tranMat, 0.0, 0.0, 0.0);

		spriteInfo[i]->spriteCenter = scalMul * spriteInfo[i]->spriteCenter;
		spriteInfo[i]->color = D3DCOLOR_XRGB(255, 255, 255);
	}

	//Textures
	//640x480 sized
	D3DXCreateTextureFromFile(DirectDevice, L"GameGrid_Sprite.png", &Texture[0]);
	D3DXCreateTextureFromFile(DirectDevice, L"MarkerO_Sprite.png", &Texture[1]);
	D3DXCreateTextureFromFile(DirectDevice, L"MarkerX_Sprite.png", &Texture[2]);
	D3DXCreateTextureFromFile(DirectDevice, L"HighScore_Background.png", &Texture[3]);
	D3DXCreateTextureFromFile(DirectDevice, L"menuScreen.png", &Texture[4]);
}

void JMDirectXFrame::Update(float dt)
{
	byte buffer[256];
	ZeroMemory(buffer, sizeof(buffer));
	
	HRESULT hr;
	hr = DIKeyboard->GetDeviceState( sizeof(buffer), (LPVOID)&buffer );

	if(FAILED(hr))
	{
		hr = DIKeyboard->Acquire();
		while( hr == DIERR_INPUTLOST)
		{
			hr = DIKeyboard->Acquire();
		}
		if(FAILED(hr))
			return;
		DIKeyboard->GetDeviceState(sizeof(buffer), buffer);
	}
	if(videoPlay)
	{
		if(buffer[DIK_RETURN] & 0x80)
		{
			Control->Stop();
			videoPlay = false;

			VideoWindow->put_Visible(OAFALSE);
			VideoWindow->put_Owner((OAHWND)hand2Wnd);

			
			SAFE_RELEASE(Control);
			SAFE_RELEASE(VideoWindow);
			SAFE_RELEASE(GraphBuilder);
		}
	}

	long evCode, param1, param2;

	if(SUCCEEDED(Media->GetEvent(&evCode, &param1, &param2, 0)))
	{
		Media->FreeEventParams(evCode, param1, param2);

		// If video is complete (EC_COMPLETE)
		if(evCode == EC_COMPLETE)
		{
			// Act on complete call here. (Continue with next game state, etc)
			Control->Stop();
			videoPlay = false;

			VideoWindow->put_Visible(OAFALSE);
			VideoWindow->put_Owner((OAHWND)hand2Wnd);

			// Clean up DirectShow variables now that it is completed.
			SAFE_RELEASE(Control);
			SAFE_RELEASE(VideoWindow);
			SAFE_RELEASE(GraphBuilder);
		}
	}

	if(!videoPlay)
	{
		switch(Game.ReturnState())
		{
		case(0):
			{
				if(buffer[DIK_NUMPAD1] | buffer[DIK_1] & 0x80)
				{
					Game.ChangeStates(1);
				}
				if(buffer[DIK_NUMPAD2] | buffer[DIK_2] & 0x80)
				{
					Game.ChangeStates(2);
				}
				if(buffer[DIK_NUMPAD3] | buffer[DIK_3] & 0x80)
				{
					Game.ChangeStates(3);
				}
				if(buffer[DIK_NUMPAD4] | buffer[DIK_4] & 0x80)
				{
					Game.ChangeStates(4);
				}
				break;
			}
		case(1):
			{
				if(buffer[DIK_ESCAPE] & 0x80)
				{
					Game.ChangeStates(0);
				}
				if(!Game.ReturnMyTurn())
				{
					if(buffer[DIK_NUMPAD1] & 0x80)
					{
						Game.MoveMade(0);
					}
					if(buffer[DIK_NUMPAD2] & 0x80)
					{
						Game.MoveMade(1);
					}
					if(buffer[DIK_NUMPAD3] & 0x80)
					{
						Game.MoveMade(2);
					}
					if(buffer[DIK_NUMPAD4] & 0x80)
					{
						Game.MoveMade(3);
					}
					if(buffer[DIK_NUMPAD5] & 0x80)
					{
						Game.MoveMade(4);
					}
					if(buffer[DIK_NUMPAD6] & 0x80)
					{
						Game.MoveMade(5);
					}
					if(buffer[DIK_NUMPAD7] & 0x80)
					{
						Game.MoveMade(6);
					}
					if(buffer[DIK_NUMPAD8] & 0x80)
					{
						Game.MoveMade(7);
					}
					if(buffer[DIK_NUMPAD9] & 0x80)
					{
						Game.MoveMade(8);
					}
				}
				else
				{
					Game.TurnJoshua();
				}
				Game.ChangeTurns();
				break;
			}
		case(2):
			{
				if(buffer[DIK_ESCAPE] & 0x80)
				{
					Game.ChangeStates(0);
				}
				break;
			}
		case(3):
			{
				if(buffer[DIK_ESCAPE] & 0x80)
				{
					Game.ChangeStates(0);
				}
				break;
			}
			
		}
	}
}

void JMDirectXFrame::Render()
{
	if(!videoPlay)
	{
		if(!DirectDevice)
			return;
		if(SUCCEEDED(DirectDevice->Clear(0, 0, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DXCOLOR(0.0f, 0.0f, 0.0f, 1.0f), 1.0f, 0)));
		{
			if(SUCCEEDED(DirectDevice->BeginScene()));
			{
				Sprite->Begin(D3DXSPRITE_ALPHABLEND);
				
				switch(Game.ReturnState())
				{
				case(0):
					{
						RECT rect;
						GetWindowRect(hand2Wnd, &rect);
						rect.top = mode.Height/10;

						TitleFont->DrawTextA(0, "TIC TAC TOE\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/10;
						GameFont->DrawTextA(0, "Shall we play a game? Press 1\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/10;
						GameFont->DrawTextA(0, "Shall we review controls? Press 2\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/10;
						GameFont->DrawTextA(0, "How about a nice game of Global Thermal Nuclear HighScores? Press 3\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/10;
						GameFont->DrawTextA(0, "The only move is not to play. Press 4", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						
						break;
					}
				case(1):
					{
						RECT rect;
						GetWindowRect(hand2Wnd, &rect);

						D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

						D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 0.0, 0.0);

						D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
						D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

						Sprite->SetTransform(&spriteInfo[0]->worldMat);
						Sprite->Draw(Texture[0], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						
						if(Game.ReturnGameGrid(0) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220*scalMul, 155*scalMul, 0.0);

							//D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(1) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(2) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, 155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(3) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220.0*scalMul, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(4) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(5) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}

						if(Game.ReturnGameGrid(6) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220*scalMul, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(7) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(8) == 0)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[1], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						



						if(Game.ReturnGameGrid(0) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220*scalMul, 155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(1) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(2) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, 155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(3) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220.0*scalMul, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(4) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(5) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, 0.0, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(6) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, -220*scalMul, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(7) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						if(Game.ReturnGameGrid(8) == 1)
						{
							D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

							D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 220*scalMul, -155*scalMul, 0.0);

							D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
							D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

							Sprite->SetTransform(&spriteInfo[0]->worldMat);
							Sprite->Draw(Texture[2], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);
						}
						break;
					}
				case(2):
					{
						RECT rect;
						GetWindowRect(hand2Wnd, &rect);
						rect.top = mode.Height/10;

						TitleFont->DrawTextA(0, "Controls\n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top = mode.Height/5;
						GameFont->DrawTextA(0, "To place a marker in the game grid press the number pad button corresponding to the same position you wish to place.\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/5;
						GameFont->DrawTextA(0, "Press Escape at anytime/anywhere to return to the main menu.", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));

						break;
					}
				case(3):
					{
						RECT rect;
						rect.top = mode.Height/20;
						rect.bottom = mode.Height;
						rect.left = mode.Width - mode.Width;
						rect.right = mode.Width/2;
						
						D3DXMatrixIdentity(&spriteInfo[0]->worldMat);

						D3DXMatrixTranslation(&spriteInfo[0]->tranMat, 0.0, 0.0, 0.0);

						//D3DXMatrixMultiply(&spriteInfo[0]->scalMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->rotMat);
					//	D3DXMatrixMultiply(&spriteInfo[0]->worldMat, &spriteInfo[0]->scalMat, &spriteInfo[0]->tranMat);

						Sprite->SetTransform(&spriteInfo[0]->worldMat);
						Sprite->Draw(Texture[3], 0, &spriteInfo[0]->spriteCenter, 0, spriteInfo[0]->color);

						TitleFont->DrawTextA(0, "High Scores\n", -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));

						Game.GetHighScores();
						char* buffer;
						buffer = Game.ReturnHighScore(1);


						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#1. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						GameFont->DrawTextA(0, buffer, -1, &rect, DT_TOP | DT_CENTER | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#2. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#3. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#4. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#5. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#6. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#7. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#8. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#9. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						rect.top += mode.Height/20;
						GameFont->DrawTextA(0, "#10. \n", -1, &rect, DT_TOP | DT_LEFT | DT_NOCLIP , D3DCOLOR_ARGB(255, 255, 255, 255));
						break;
					}
				case(4):
					{
						PostQuitMessage(0);
						break;
					}
				}
				
				Sprite->End();


				RECT rect;
				GetWindowRect(hand2Wnd, &rect);

				GameFont->DrawTextA(0, "Joshua Murrill\n", -1, &rect, DT_TOP | DT_RIGHT | DT_NOCLIP, D3DCOLOR_ARGB(255, 255, 255, 255));
				static char buffer[64];
				sprintf_s(buffer, 64, "FPS: %d\n", FPS);
				GameFont->DrawTextA(0, buffer, -1, &rect, DT_TOP | DT_NOCLIP, D3DCOLOR_ARGB(255, 255, 255, 255));

				DirectDevice->EndScene();
				
				DirectDevice->Present(0, 0, 0, 0);
			}
			currTime = (float)timeGetTime();
			static int fpsCounter = 0;
			if(currTime - prevTime >= 1000.0f)
			{
				prevTime = currTime;
				FPS = fpsCounter;
				fpsCounter = 0;		
			}
			else
			{
				fpsCounter++;
			}
		}
	}
}

 void JMDirectXFrame::Shutdown()
 {
	 SAFE_RELEASE(DIMouse);
	 SAFE_RELEASE(DIKeyboard);
	 SAFE_RELEASE(DIObject);
	 for(int i = 0; i < 5; i++)
		SAFE_RELEASE(Texture[i]);
	 SAFE_RELEASE(Sprite);
	 SAFE_RELEASE(GameFont);
	 SAFE_RELEASE(DirectDevice);
	 SAFE_RELEASE(DirectObject);
 }