class IAM
{
private:
	bool myTurn;
	int gameGrid[9];
	int w2wSelf[9];
	int selfProg[9];
	int nextMove[9];
	int move;
public:
	IAM();
	bool ReturnMyTurn();
	void ChangeTurns();
	void FillPos(int pos);
	int ReturnPosFill(int pos);
	void UpdateW2W();
	void UpdateSelfProg(int pos);
	void CalcMove();
};