#include<string>
#include<Windows.h>
#include"IAM.h"

using namespace std;

class TicTacToe
{
private:
	int gameState;
	char* highScores[13];
	IAM Joshua;
public:
	TicTacToe();
	void ChangeStates(int nextState);
	int ReturnState();
	void GetHighScores();
	char* ReturnHighScore(int num);
	int ReturnGameGrid(int pos);
	bool ReturnMyTurn();
	void ChangeTurns();
	void TicTacToe::MoveMade(int pos);
	void TurnJoshua();
};