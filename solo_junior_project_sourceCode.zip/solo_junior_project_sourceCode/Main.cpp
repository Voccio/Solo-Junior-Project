#include<iostream>
using namespace std;
#include<Windows.h>
#include"DirectX.h"

#define WINDOW_TITLE L"TicTacToe"

HWND gameWnd;
HINSTANCE gameInstance;
bool gameWindowed;

JMDirectXFrame DXFrame;

int WINAPI wWinMain(HINSTANCE hInstance,	// Handle to the application
				   HINSTANCE hPrevInstance,	// Handle to the previous app
				   LPTSTR lpCmdLine,		// Command line string
				   int lpCmdShow);			// Show window value

LRESULT CALLBACK WndProc(HWND hWnd,			// Handle to the window
						 UINT message,		// Incoming Message
						 WPARAM wparam,		// Message Info
						 LPARAM lparam);	// Message Info

void InitWindow(void)
{
	WNDCLASSEX wndClass;  
	ZeroMemory(&wndClass, sizeof(wndClass));

	wndClass.cbSize			= sizeof(WNDCLASSEX);			// size of window structure
	wndClass.lpfnWndProc	= (WNDPROC)WndProc;				// message callback
	wndClass.lpszClassName	= WINDOW_TITLE;					// class name -> a required field here, can't put NULL
	wndClass.hInstance		= gameInstance;					// handle to the application
	wndClass.hCursor		= LoadCursor(NULL, IDC_CROSS);	// changed t a CROSS pointer
	wndClass.hbrBackground	= (HBRUSH)(COLOR_WINDOWFRAME);	// background brush

	RegisterClassEx(&wndClass);

	gameWnd = CreateWindow(
		WINDOW_TITLE, WINDOW_TITLE,
		gameWindowed ? WS_OVERLAPPEDWINDOW | WS_VISIBLE:(WS_POPUP | WS_VISIBLE),
		CW_USEDEFAULT, CW_USEDEFAULT,
		800, 600,
		NULL, NULL,
		gameInstance,
		NULL);

	ShowWindow(gameWnd, SW_SHOW);
	UpdateWindow(gameWnd);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	gameInstance = hInstance;
	gameWindowed = false;

	InitWindow();

	MSG msg; 
	ZeroMemory(&msg, sizeof(msg));

	DXFrame.Init(gameWnd, gameInstance, gameWindowed);

	__int64 cntsPerSec = 0;
	QueryPerformanceFrequency((LARGE_INTEGER*)&cntsPerSec);
	float secsPerCnt = 1.0f / (float)cntsPerSec;

	__int64 prevTimeStamp = 0;
	QueryPerformanceCounter((LARGE_INTEGER*)&prevTimeStamp);

	while(msg.message != WM_QUIT)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		__int64 currTimeStamp = 0;
		QueryPerformanceCounter((LARGE_INTEGER*)&currTimeStamp);
		float dt = (currTimeStamp - prevTimeStamp) * secsPerCnt;

		DXFrame.Update(dt);
		DXFrame.Render();

		prevTimeStamp = currTimeStamp;
	}
	DXFrame.Shutdown();
	UnregisterClass(WINDOW_TITLE, gameInstance);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	switch(message)
	{
		case (WM_PAINT):
		{
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		}		
		case(WM_DESTROY):
		{
			PostQuitMessage(0); 
			break;
		}
	}
	return DefWindowProc(hWnd, message, wparam, lparam);
}