#pragma once
#include<stdio.h>
#pragma comment(lib, "winmm.lib")
#include<d3d9.h>
#include<d3dx9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

#define DIRECTINPUT_VERSION 0x0800

#include<dinput.h>
#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxguid.lib")

#include"fmod.hpp"
#pragma comment(lib, "fmod_vc.lib")

#include<dshow.h>
#pragma comment(lib, "strmiids.lib")

#include"TicTacToe.h"

#include<iostream>



#define SAFE_RELEASE(x) if(x){x->Release(); x = 0;}

struct SpriteInfo
{
	D3DXMATRIX          worldMat;
	D3DXMATRIX          scalMat;
	D3DXMATRIX          rotMat;
	D3DXMATRIX          tranMat;
	D3DCOLOR            color;
	D3DXVECTOR3         spriteCenter;
};

class JMDirectXFrame
{



private:
	HWND				hand2Wnd;
	bool				vSync;

	IDirect3D9*			DirectObject;
	IDirect3DDevice9*	DirectDevice;
	D3DCAPS9			DeviceCap;
	D3DDISPLAYMODE		mode;
	ID3DXFont*			GameFont;
	ID3DXFont*			TitleFont;

	//Input/Output
	IDirectInput8*			DIObject;
	IDirectInputDevice8*	DIKeyboard;
	IDirectInputDevice8*	DIMouse;
	byte					KeyboardState[256];
	DIMOUSESTATE2			MouseState;

	//FPS variables
	float				currTime, prevTime;
	int					FPS;
	
	//FMOD Setup
	#define ERRCHECK(x) if(x != FMOD_OK) {MessageBox(hand2Wnd, (LPCWSTR)x, L"Fmod Error", MB_OK);}

	FMOD::System*		AudSystem;
	FMOD_RESULT			AudResult;
	unsigned int		version;
	int					numDrivers;
	FMOD_SPEAKERMODE	SpeakerMode;
	FMOD_CAPS			AudCap;
	char				name[256];
		
	FMOD::Sound*		Sound;
	FMOD::Channel*		Channel;

	IGraphBuilder*		GraphBuilder;
	IMediaControl*		Control;
	IMediaEvent*		Media;
	IVideoWindow*		VideoWindow;

	bool				videoPlay;

	//Sprites
	ID3DXSprite*		Sprite;
	IDirect3DTexture9*	Texture[5];
	D3DXIMAGE_INFO		ImageInfo;
	SpriteInfo*			spriteInfo[5];
	float				scalMul;

	//Game
	TicTacToe			Game;

public:
	JMDirectXFrame();
	~JMDirectXFrame();
	void Init(HWND &hWnd, HINSTANCE &hInstance, bool windowed);
	void Update(float dt);
	void Render();
	void Shutdown();
};