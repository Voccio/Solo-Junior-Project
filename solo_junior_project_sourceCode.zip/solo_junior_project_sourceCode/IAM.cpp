#include"IAM.h"

IAM::IAM()
{
	myTurn = false;
	for(int i = 0; i < 9; i++)
	{
		gameGrid[i] = 2;
		selfProg[i] = 0;
		nextMove[i] = 0;
	}

	move = 0;

	int temp = 0;
	temp = gameGrid[0]*gameGrid[1]*gameGrid[2];
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[1]++;
		w2wSelf[2]++;
	}
	temp = gameGrid[3]*gameGrid[4]*gameGrid[5];
	if(temp > 0)
	{
		w2wSelf[3]++;
		w2wSelf[4]++;
		w2wSelf[5]++;
	}
	temp = gameGrid[6]*gameGrid[7]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[6]++;
		w2wSelf[7]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[0]*gameGrid[3]*gameGrid[6];
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[3]++;
		w2wSelf[6]++;
	}
	temp = gameGrid[1]*gameGrid[4]*gameGrid[7];
	if(temp > 0)
	{
		w2wSelf[1]++;
		w2wSelf[4]++;
		w2wSelf[7]++;
	}
	temp = gameGrid[2]*gameGrid[5]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[2]++;
		w2wSelf[5]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[0]*gameGrid[4]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[4]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[2]*gameGrid[4]*gameGrid[6];
	if(temp > 0)
	{
		w2wSelf[2]++;
		w2wSelf[4]++;
		w2wSelf[6]++;
	}
}

bool IAM::ReturnMyTurn()
{
	return myTurn;
}

void IAM::ChangeTurns()
{
	if(myTurn)
		myTurn = false;
	else if(!myTurn)
		myTurn = true;
}

void IAM::FillPos(int pos)
{
	if(myTurn)
	{
		gameGrid[pos] = 1;
		UpdateSelfProg(pos);
	}
	else
	{
		gameGrid[pos] = 0;
		UpdateW2W();
	}
}

int IAM::ReturnPosFill(int pos)
{
	return gameGrid[pos];
}

void IAM::UpdateW2W()
{
	for(int i = 0; i < 9; i++)
	{
		w2wSelf[i] = 0;
	}

	int temp = 0;
	temp = gameGrid[0]*gameGrid[1]*gameGrid[2];
	
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[1]++;
		w2wSelf[2]++;
	}
	temp = gameGrid[3]*gameGrid[4]*gameGrid[5];
	if(temp > 0)
	{
		w2wSelf[3]++;
		w2wSelf[4]++;
		w2wSelf[5]++;
	}
	temp = gameGrid[6]*gameGrid[7]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[6]++;
		w2wSelf[7]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[0]*gameGrid[3]*gameGrid[6];
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[3]++;
		w2wSelf[6]++;
	}
	temp = gameGrid[1]*gameGrid[4]*gameGrid[7];
	if(temp > 0)
	{
		w2wSelf[1]++;
		w2wSelf[4]++;
		w2wSelf[7]++;
	}
	temp = gameGrid[2]*gameGrid[5]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[2]++;
		w2wSelf[5]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[0]*gameGrid[4]*gameGrid[8];
	if(temp > 0)
	{
		w2wSelf[0]++;
		w2wSelf[4]++;
		w2wSelf[8]++;
	}
	temp = gameGrid[2]*gameGrid[4]*gameGrid[6];
	if(temp > 0)
	{
		w2wSelf[2]++;
		w2wSelf[4]++;
		w2wSelf[6]++;
	}
}

void IAM::UpdateSelfProg(int pos)
{
	switch(pos)
	{
	case(0):
		{
			selfProg[0]++;
			selfProg[1]++;
			selfProg[2]++;
			selfProg[3]++;
			selfProg[4]++;
			selfProg[6]++;
			selfProg[8]++;
			break;
		}
	case(1):
		{
			selfProg[0]++;
			selfProg[1]++;
			selfProg[2]++;
			selfProg[4]++;
			selfProg[7]++;
			break;
		}
	case(2):
		{
			selfProg[0]++;
			selfProg[1]++;
			selfProg[2]++;
			selfProg[4]++;
			selfProg[5]++;
			selfProg[6]++;
			selfProg[8]++;
			break;
		}
	case(3):
		{
			selfProg[0]++;
			selfProg[3]++;
			selfProg[4]++;
			selfProg[5]++;
			selfProg[6]++;
			break;
		}
	case(4):
		{
			selfProg[0]++;
			selfProg[1]++;
			selfProg[2]++;
			selfProg[3]++;
			selfProg[4]++;
			selfProg[5]++;
			selfProg[6]++;
			selfProg[7]++;
			selfProg[8]++;
			break;
		}
	case(5):
		{
			selfProg[2]++;
			selfProg[3]++;
			selfProg[4]++;
			selfProg[5]++;
			selfProg[8]++;
			break;
		}
	case(6):
		{
			selfProg[0]++;
			selfProg[2]++;
			selfProg[3]++;
			selfProg[4]++;
			selfProg[6]++;
			selfProg[7]++;
			selfProg[8]++;
			break;
		}
	case(7):
		{
			selfProg[1]++;
			selfProg[4]++;
			selfProg[6]++;
			selfProg[7]++;
			selfProg[8]++;
			break;
		}
	case(8):
		{
			selfProg[0]++;
			selfProg[4]++;
			selfProg[5]++;
			selfProg[6]++;
			selfProg[7]++;
			selfProg[8]++;
			break;
		}
	}
}

void IAM::CalcMove()
{
	for(int i = 0; i < 9; i++)
	{
		if(gameGrid[i] == 2)
		{
			if(selfProg[i] == 2)
			{
				nextMove[i] = 10;
			}
			else
			{
				nextMove[i] = selfProg[i] + w2wSelf[i];
			}
		}
	}
	for(int i = 0; i < 8; i++)
	{
		if(nextMove[i] >= nextMove[i + 1])
		{
			move = i;
		}
	}
	if(nextMove[8] > move)
	{
		move = 8;
	}

	FillPos(move);
}