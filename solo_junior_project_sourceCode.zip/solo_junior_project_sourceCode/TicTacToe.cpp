#include"TicTacToe.h"


TicTacToe::TicTacToe()
{
	gameState = 0;
}

void TicTacToe::ChangeStates(int nextState)
{
	gameState = nextState;
}

int TicTacToe::ReturnState()
{
	return gameState;
}


void TicTacToe::GetHighScores()
{
	for(int i = 0; i < 10; i++)
	{
		ReadFile("highScores.txt", highScores[i], 13, 0, 0);
	}
}

char* TicTacToe::ReturnHighScore(int num)
{
	return highScores[num];
}

int TicTacToe::ReturnGameGrid(int pos)
{
	return Joshua.ReturnPosFill(pos);
}

bool TicTacToe::ReturnMyTurn()
{
	return Joshua.ReturnMyTurn();
}

void TicTacToe::ChangeTurns()
{
	Joshua.ChangeTurns();
}

void TicTacToe::MoveMade(int pos)
{
	Joshua.FillPos(pos);
}

void TicTacToe::TurnJoshua()
{
	Joshua.CalcMove();
}